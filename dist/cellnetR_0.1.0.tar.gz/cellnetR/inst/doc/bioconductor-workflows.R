## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----eval=FALSE---------------------------------------------------------------
# library(cellnetR)
# network <- cellnet_from_omnipath(OmnipathR::import_all_interactions())
# compiled <- cellnet_compile(network)
# screen <- perturb_batch(compiled, c("BRAF", "MAP2K1", "MAPK1"), effect = -1)

## ----eval=FALSE---------------------------------------------------------------
# net <- cellnet_from_carnival(carnival_result)
# drug_screen <- perturb_batch(cellnet_compile(net), drug_targets, effect = -1)

## ----eval=FALSE---------------------------------------------------------------
# activity <- decoupleR_result
# compiled <- cellnet_compile(network)
# set_activity_context(compiled, activity, condition = "treated")

## ----eval=FALSE---------------------------------------------------------------
# pathway_net <- cellnet_from_graphite(pathway_edges, sign = 1)
# causal_cone(pathway_net, "EGFR")

